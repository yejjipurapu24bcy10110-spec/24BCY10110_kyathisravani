package com.college.management;

import com.college.management.dto.BookRequest;
import com.college.management.dto.DepartmentRequest;
import com.college.management.dto.StaffRequest;
import com.college.management.dto.StudentRequest;
import com.college.management.model.Book;
import com.college.management.model.Department;
import com.college.management.model.Staff;
import com.college.management.model.Student;
import com.college.management.repository.BookRepository;
import com.college.management.repository.DepartmentRepository;
import com.college.management.repository.StaffRepository;
import com.college.management.repository.StudentRepository;
import com.college.management.service.BookService;
import com.college.management.service.DepartmentService;
import com.college.management.service.StaffService;
import com.college.management.service.StudentService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ManagementApplicationTests {

	@Autowired
	private DepartmentService departmentService;
	@Autowired
	private StaffService staffService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private BookService bookService;

	@Autowired
	private DepartmentRepository departmentRepository;
	@Autowired
	private StaffRepository staffRepository;
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private BookRepository bookRepository;

	@BeforeEach
	@AfterEach
	void cleanUp() {
		studentRepository.deleteAll();
		bookRepository.deleteAll();
		departmentRepository.deleteAll();
		staffRepository.deleteAll();
	}

	@Test
	void testCompleteCollegeManagementFlow() {
		// 1. Create a Department
		DepartmentRequest deptReq = new DepartmentRequest("Computer Science", "CS", null);
		Department csDept = departmentService.createDepartment(deptReq);
		assertNotNull(csDept.getId());
		assertEquals("Computer Science", csDept.getName());
		assertEquals("CS", csDept.getCode());
		assertNull(csDept.getHod());

		// 2. Create a Staff member
		StaffRequest staffReq = new StaffRequest("Dr. John Doe", "john.doe@college.edu", "Professor", csDept.getId());
		Staff professor = staffService.createStaff(staffReq);
		assertNotNull(professor.getId());
		assertEquals("Dr. John Doe", professor.getName());
		assertNotNull(professor.getDepartment());
		assertEquals(csDept.getId(), professor.getDepartment().getId());

		// 3. Assign Staff as HOD (1:1 Relationship)
		csDept = departmentService.assignHod(csDept.getId(), professor.getId());
		assertNotNull(csDept.getHod());
		assertEquals(professor.getId(), csDept.getHod().getId());

		// Verify bi-directional link in Staff
		Staff updatedProfessor = staffService.getStaffById(professor.getId());
		assertNotNull(updatedProfessor.getDepartment());
		assertEquals(csDept.getId(), updatedProfessor.getDepartment().getId());

		// 4. Create a Student in Department (1:M Relationship)
		StudentRequest studentReq = new StudentRequest("Alice Smith", "alice@student.college.edu", csDept.getId());
		Student alice = studentService.createStudent(studentReq);
		assertNotNull(alice.getId());
		assertEquals("Alice Smith", alice.getName());
		assertNotNull(alice.getDepartment());
		assertEquals(csDept.getId(), alice.getDepartment().getId());

		// 5. Create a Book associated with Department (M:1 Relationship)
		BookRequest bookReq = new BookRequest("Introduction to Algorithms", "CLRS", "9780262033848", csDept.getId());
		Book algorithmsBook = bookService.createBook(bookReq);
		assertNotNull(algorithmsBook.getId());
		assertEquals("Introduction to Algorithms", algorithmsBook.getTitle());
		assertNotNull(algorithmsBook.getDepartment());
		assertEquals(csDept.getId(), algorithmsBook.getDepartment().getId());

		// 6. Borrow Book (Many-to-Many Relationship)
		alice = studentService.borrowBook(alice.getId(), algorithmsBook.getId());
		algorithmsBook = bookService.getBookById(algorithmsBook.getId());

		// Verify Student has Book
		assertEquals(1, alice.getBorrowedBooks().size());
		assertEquals(algorithmsBook.getId(), alice.getBorrowedBooks().get(0).getId());

		// Verify Book has Student
		assertEquals(1, algorithmsBook.getBorrowers().size());
		assertEquals(alice.getId(), algorithmsBook.getBorrowers().get(0).getId());

		// 7. Return Book (Many-to-Many Unlink)
		alice = studentService.returnBook(alice.getId(), algorithmsBook.getId());
		algorithmsBook = bookService.getBookById(algorithmsBook.getId());

		assertTrue(alice.getBorrowedBooks().isEmpty());
		assertTrue(algorithmsBook.getBorrowers().isEmpty());

		// 8. Test Cascade Deletion Cleanup
		// Let's borrow the book again to test cleanup of borrowed reference on delete
		alice = studentService.borrowBook(alice.getId(), algorithmsBook.getId());
		
		// Delete Book
		bookService.deleteBook(algorithmsBook.getId());
		
		// Verify Student's borrowed list is empty now
		alice = studentService.getStudentById(alice.getId());
		assertTrue(alice.getBorrowedBooks().isEmpty());

		// Delete Department
		departmentService.deleteDepartment(csDept.getId());

		// Verify Student and Professor department references are cleared (set to null)
		alice = studentService.getStudentById(alice.getId());
		assertTrue(alice.getDepartment() == null || alice.getDepartment().getId() == null);

		updatedProfessor = staffService.getStaffById(professor.getId());
		assertTrue(updatedProfessor.getDepartment() == null || updatedProfessor.getDepartment().getId() == null);
	}
}
