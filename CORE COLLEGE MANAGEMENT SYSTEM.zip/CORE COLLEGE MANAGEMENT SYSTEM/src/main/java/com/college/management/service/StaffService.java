package com.college.management.service;

import com.college.management.dto.StaffRequest;
import com.college.management.model.Department;
import com.college.management.model.Staff;
import com.college.management.repository.DepartmentRepository;
import com.college.management.repository.StaffRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StaffService {

    private final StaffRepository staffRepository;
    private final DepartmentRepository departmentRepository;

    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    public Staff getStaffById(String id) {
        return staffRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Staff not found with ID: " + id));
    }

    @Transactional
    public Staff createStaff(StaffRequest request) {
        Staff staff = Staff.builder()
                .name(request.getName())
                .email(request.getEmail())
                .designation(request.getDesignation())
                .build();

        if (request.getDepartmentId() != null && !request.getDepartmentId().trim().isEmpty()) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new RuntimeException("Department not found with ID: " + request.getDepartmentId()));
            staff.setDepartment(department);
        }

        return staffRepository.save(staff);
    }

    @Transactional
    public Staff updateStaff(String id, StaffRequest request) {
        Staff staff = getStaffById(id);
        staff.setName(request.getName());
        staff.setEmail(request.getEmail());
        staff.setDesignation(request.getDesignation());

        String oldDeptId = staff.getDepartment() != null ? staff.getDepartment().getId() : null;
        String newDeptId = request.getDepartmentId();

        if (newDeptId != null && !newDeptId.trim().isEmpty()) {
            if (oldDeptId == null || !oldDeptId.equals(newDeptId)) {
                // Changing department: Check if HOD of the old department and clear it
                if (oldDeptId != null) {
                    departmentRepository.findById(oldDeptId).ifPresent(oldDept -> {
                        if (oldDept.getHod() != null && oldDept.getHod().getId() != null && oldDept.getHod().getId().equals(id)) {
                            oldDept.setHod(null);
                            departmentRepository.save(oldDept);
                        }
                    });
                }

                Department department = departmentRepository.findById(newDeptId)
                        .orElseThrow(() -> new RuntimeException("Department not found with ID: " + newDeptId));
                staff.setDepartment(department);
            }
        } else {
            // Clearing department reference
            if (oldDeptId != null) {
                departmentRepository.findById(oldDeptId).ifPresent(oldDept -> {
                    if (oldDept.getHod() != null && oldDept.getHod().getId() != null && oldDept.getHod().getId().equals(id)) {
                        oldDept.setHod(null);
                        departmentRepository.save(oldDept);
                    }
                });
            }
            staff.setDepartment(null);
        }

        return staffRepository.save(staff);
    }

    @Transactional
    public void deleteStaff(String id) {
        Staff staff = getStaffById(id);

        // If this staff member is HOD of any department, clear it
        departmentRepository.findAll().forEach(dept -> {
            if (dept.getHod() != null && dept.getHod().getId() != null && dept.getHod().getId().equals(id)) {
                dept.setHod(null);
                departmentRepository.save(dept);
            }
        });

        staffRepository.delete(staff);
    }
}
