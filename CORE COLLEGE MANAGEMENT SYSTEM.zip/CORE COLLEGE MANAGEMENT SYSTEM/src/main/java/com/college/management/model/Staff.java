package com.college.management.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "staff")
public class Staff {

    @Id
    private String id;
    private String name;
    private String email;
    private String designation;

    @DocumentReference(lazy = true)
    @JsonIgnoreProperties({"hod", "students", "books"})
    private Department department;
}
