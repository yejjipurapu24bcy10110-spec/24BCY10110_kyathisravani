package com.college.management.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StaffRequest {
    private String name;
    private String email;
    private String designation;
    private String departmentId; // Optional Department assignment
}
