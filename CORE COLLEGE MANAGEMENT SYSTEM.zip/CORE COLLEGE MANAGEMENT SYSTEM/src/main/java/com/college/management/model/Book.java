package com.college.management.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "books")
public class Book {

    @Id
    private String id;
    private String title;
    private String author;
    private String isbn;

    @DocumentReference(lazy = true)
    @JsonIgnoreProperties({"hod", "students", "books"})
    private Department department;

    @DocumentReference(lazy = true)
    @Builder.Default
    @JsonIgnoreProperties({"borrowedBooks", "department"})
    private List<Student> borrowers = new ArrayList<>();
}
