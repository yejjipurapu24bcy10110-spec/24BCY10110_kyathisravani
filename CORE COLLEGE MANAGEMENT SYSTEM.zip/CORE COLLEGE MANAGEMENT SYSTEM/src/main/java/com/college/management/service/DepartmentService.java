package com.college.management.service;

import com.college.management.dto.DepartmentRequest;
import com.college.management.model.Book;
import com.college.management.model.Department;
import com.college.management.model.Staff;
import com.college.management.model.Student;
import com.college.management.repository.BookRepository;
import com.college.management.repository.DepartmentRepository;
import com.college.management.repository.StaffRepository;
import com.college.management.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final StaffRepository staffRepository;
    private final StudentRepository studentRepository;
    private final BookRepository bookRepository;

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    public Department getDepartmentById(String id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found with ID: " + id));
    }

    @Transactional
    public Department createDepartment(DepartmentRequest request) {
        Department department = Department.builder()
                .name(request.getName())
                .code(request.getCode())
                .build();

        if (request.getHodId() != null && !request.getHodId().trim().isEmpty()) {
            Staff hod = staffRepository.findById(request.getHodId())
                    .orElseThrow(() -> new RuntimeException("Staff not found with ID: " + request.getHodId()));
            department.setHod(hod);
        }

        Department savedDepartment = departmentRepository.save(department);

        // If HOD was set, update HOD's department reference
        if (savedDepartment.getHod() != null) {
            Staff hod = savedDepartment.getHod();
            hod.setDepartment(savedDepartment);
            staffRepository.save(hod);
        }

        return savedDepartment;
    }

    @Transactional
    public Department updateDepartment(String id, DepartmentRequest request) {
        Department department = getDepartmentById(id);
        department.setName(request.getName());
        department.setCode(request.getCode());

        // Handle HOD update
        Staff oldHod = department.getHod();
        if (request.getHodId() != null && !request.getHodId().trim().isEmpty()) {
            Staff newHod = staffRepository.findById(request.getHodId())
                    .orElseThrow(() -> new RuntimeException("Staff not found with ID: " + request.getHodId()));
            
            if (oldHod == null || oldHod.getId() == null || !oldHod.getId().equals(newHod.getId())) {
                // Clear old HOD's department reference if it was pointing here
                if (oldHod != null && oldHod.getId() != null) {
                    oldHod.setDepartment(null);
                    staffRepository.save(oldHod);
                }
                department.setHod(newHod);
                newHod.setDepartment(department);
                staffRepository.save(newHod);
            }
        } else {
            // HOD cleared
            if (oldHod != null && oldHod.getId() != null) {
                oldHod.setDepartment(null);
                staffRepository.save(oldHod);
            }
            department.setHod(null);
        }

        return departmentRepository.save(department);
    }

    @Transactional
    public void deleteDepartment(String id) {
        Department department = getDepartmentById(id);

        // Clear reference from Staff members who belong to this department
        List<Staff> staffMembers = staffRepository.findByDepartmentId(id);
        for (Staff staff : staffMembers) {
            staff.setDepartment(null);
            staffRepository.save(staff);
        }

        // Clear reference from Students who belong to this department
        List<Student> students = studentRepository.findByDepartmentId(id);
        for (Student student : students) {
            student.setDepartment(null);
            studentRepository.save(student);
        }

        // Clear reference from Books that belong to this department
        List<Book> books = bookRepository.findByDepartmentId(id);
        for (Book book : books) {
            book.setDepartment(null);
            bookRepository.save(book);
        }

        departmentRepository.delete(department);
    }

    @Transactional
    public Department assignHod(String departmentId, String staffId) {
        Department department = getDepartmentById(departmentId);
        Staff staff = staffRepository.findById(staffId)
                .orElseThrow(() -> new RuntimeException("Staff not found with ID: " + staffId));

        Staff oldHod = department.getHod();
        if (oldHod != null && oldHod.getId() != null && !oldHod.getId().equals(staffId)) {
            oldHod.setDepartment(null);
            staffRepository.save(oldHod);
        }

        department.setHod(staff);
        staff.setDepartment(department);
        staffRepository.save(staff);

        return departmentRepository.save(department);
    }
}
