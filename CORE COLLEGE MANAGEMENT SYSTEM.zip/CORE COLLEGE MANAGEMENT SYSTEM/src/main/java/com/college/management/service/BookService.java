package com.college.management.service;

import com.college.management.dto.BookRequest;
import com.college.management.model.Book;
import com.college.management.model.Department;
import com.college.management.model.Student;
import com.college.management.repository.BookRepository;
import com.college.management.repository.DepartmentRepository;
import com.college.management.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository bookRepository;
    private final DepartmentRepository departmentRepository;
    private final StudentRepository studentRepository;

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book getBookById(String id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found with ID: " + id));
    }

    @Transactional
    public Book createBook(BookRequest request) {
        Book book = Book.builder()
                .title(request.getTitle())
                .author(request.getAuthor())
                .isbn(request.getIsbn())
                .borrowers(new ArrayList<>())
                .build();

        if (request.getDepartmentId() != null && !request.getDepartmentId().trim().isEmpty()) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new RuntimeException("Department not found with ID: " + request.getDepartmentId()));
            book.setDepartment(department);
        }

        return bookRepository.save(book);
    }

    @Transactional
    public Book updateBook(String id, BookRequest request) {
        Book book = getBookById(id);
        book.setTitle(request.getTitle());
        book.setAuthor(request.getAuthor());
        book.setIsbn(request.getIsbn());

        if (request.getDepartmentId() != null && !request.getDepartmentId().trim().isEmpty()) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new RuntimeException("Department not found with ID: " + request.getDepartmentId()));
            book.setDepartment(department);
        } else {
            book.setDepartment(null);
        }

        return bookRepository.save(book);
    }

    @Transactional
    public void deleteBook(String id) {
        Book book = getBookById(id);

        // Remove this book reference from students who borrowed it
        for (Student student : book.getBorrowers()) {
            if (student.getBorrowedBooks() != null) {
                student.getBorrowedBooks().removeIf(b -> b.getId() != null && b.getId().equals(id));
                studentRepository.save(student);
            }
        }

        bookRepository.delete(book);
    }
}
