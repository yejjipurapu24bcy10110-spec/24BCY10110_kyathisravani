package com.college.management.service;

import com.college.management.dto.StudentRequest;
import com.college.management.model.Book;
import com.college.management.model.Department;
import com.college.management.model.Student;
import com.college.management.repository.BookRepository;
import com.college.management.repository.DepartmentRepository;
import com.college.management.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final DepartmentRepository departmentRepository;
    private final BookRepository bookRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(String id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + id));
    }

    @Transactional
    public Student createStudent(StudentRequest request) {
        Student student = Student.builder()
                .name(request.getName())
                .email(request.getEmail())
                .borrowedBooks(new ArrayList<>())
                .build();

        if (request.getDepartmentId() != null && !request.getDepartmentId().trim().isEmpty()) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new RuntimeException("Department not found with ID: " + request.getDepartmentId()));
            student.setDepartment(department);
        }

        return studentRepository.save(student);
    }

    @Transactional
    public Student updateStudent(String id, StudentRequest request) {
        Student student = getStudentById(id);
        student.setName(request.getName());
        student.setEmail(request.getEmail());

        if (request.getDepartmentId() != null && !request.getDepartmentId().trim().isEmpty()) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new RuntimeException("Department not found with ID: " + request.getDepartmentId()));
            student.setDepartment(department);
        } else {
            student.setDepartment(null);
        }

        return studentRepository.save(student);
    }

    @Transactional
    public void deleteStudent(String id) {
        Student student = getStudentById(id);

        // Remove references from books borrowed by this student
        for (Book book : student.getBorrowedBooks()) {
            if (book.getBorrowers() != null) {
                book.getBorrowers().removeIf(s -> s.getId() != null && s.getId().equals(id));
                bookRepository.save(book);
            }
        }

        studentRepository.delete(student);
    }

    @Transactional
    public Student borrowBook(String studentId, String bookId) {
        Student student = getStudentById(studentId);
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found with ID: " + bookId));

        if (student.getBorrowedBooks() == null) {
            student.setBorrowedBooks(new ArrayList<>());
        }
        if (book.getBorrowers() == null) {
            book.setBorrowers(new ArrayList<>());
        }

        // Avoid duplicate borrowings
        boolean alreadyBorrowed = student.getBorrowedBooks().stream()
                .anyMatch(b -> b.getId() != null && b.getId().equals(bookId));

        if (!alreadyBorrowed) {
            student.getBorrowedBooks().add(book);
            book.getBorrowers().add(student);
            bookRepository.save(book);
            student = studentRepository.save(student);
        }

        return student;
    }

    @Transactional
    public Student returnBook(String studentId, String bookId) {
        Student student = getStudentById(studentId);
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found with ID: " + bookId));

        if (student.getBorrowedBooks() != null) {
            student.getBorrowedBooks().removeIf(b -> b.getId() != null && b.getId().equals(bookId));
        }
        if (book.getBorrowers() != null) {
            book.getBorrowers().removeIf(s -> s.getId() != null && s.getId().equals(studentId));
        }

        bookRepository.save(book);
        return studentRepository.save(student);
    }
}
